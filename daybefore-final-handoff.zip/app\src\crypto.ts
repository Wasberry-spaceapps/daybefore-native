// Web Crypto API utility for E2E Encryption

// Generates a random salt
export function generateSalt(): Uint8Array {
  return window.crypto.getRandomValues(new Uint8Array(16));
}

// Derives a key using PBKDF2
export async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    { name: 'PBKDF2' },
    false,
    ['deriveBits', 'deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as any,
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
}

// Encrypts an object to a Base64 string payload
export async function encryptObject(obj: any, key: CryptoKey): Promise<string> {
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const data = enc.encode(JSON.stringify(obj));

  const cipherBuffer = await window.crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    data
  );

  const cipherBytes = new Uint8Array(cipherBuffer);
  // Combine IV and Ciphertext: [IV (12 bytes)][Ciphertext]
  const payload = new Uint8Array(iv.length + cipherBytes.length);
  payload.set(iv, 0);
  payload.set(cipherBytes, iv.length);

  // Convert to Base64
  return btoa(String.fromCharCode(...payload));
}

// Decrypts a Base64 string payload back to an object
export async function decryptObject(base64Payload: string, key: CryptoKey): Promise<any> {
  const binaryStr = atob(base64Payload);
  const payload = new Uint8Array(binaryStr.length);
  for (let i = 0; i < binaryStr.length; i++) {
    payload[i] = binaryStr.charCodeAt(i);
  }

  const iv = payload.slice(0, 12);
  const cipherBytes = payload.slice(12);

  const plainBuffer = await window.crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    cipherBytes
  );

  const dec = new TextDecoder();
  return JSON.parse(dec.decode(plainBuffer));
}

// Hashes a password for sending to the server (so plaintext never leaves device)
export async function hashPassword(passphrase: string): Promise<string> {
  const enc = new TextEncoder();
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', enc.encode(passphrase));
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}
