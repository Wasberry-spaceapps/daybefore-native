import React, { useState, useEffect } from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import Landing from './Landing.tsx'
import Pricing from './Pricing.tsx'
import Auth from './Auth.tsx'
import Legal from './Legal.tsx'
import './index.css'

function Router() {
  const [hash, setHash] = useState(window.location.hash);

  useEffect(() => {
    const handleHashChange = () => setHash(window.location.hash);
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  if (hash === '#app') {
    return <App />;
  } else if (hash === '#pricing') {
    return <Pricing />;
  } else if (hash === '#auth') {
    return <Auth />;
  } else if (hash === '#legal') {
    return <Legal />;
  }

  return <Landing />;
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Router />
  </React.StrictMode>,
)
