import { useState } from 'react';
import { deriveKey, generateSalt, hashPassword } from './crypto';

const API_URL = (import.meta as any).env.VITE_API_URL || 'https://daybefore-backend.officialmutairu.workers.dev/api';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const passwordHash = await hashPassword(password);
      let payload: any = { email, passwordHash };

      let localSalt: Uint8Array | null = null;
      if (!isLogin) {
        localSalt = generateSalt();
        payload.salt = btoa(String.fromCharCode(...localSalt));
      }

      const res = await fetch(`${API_URL}/auth/${isLogin ? 'login' : 'register'}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Authentication failed');

      localStorage.setItem('daybefore_token', data.token);
      localStorage.setItem('daybefore_salt', data.salt);

      // Derive and store E2E key for this session
      const saltBin = atob(data.salt);
      const saltArr = new Uint8Array(saltBin.length);
      for(let i=0; i<saltBin.length; i++) saltArr[i] = saltBin.charCodeAt(i);
      
      const key = await deriveKey(password, saltArr);
      (window as any).e2eKey = key;

      window.location.hash = '#app';
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '48px' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 500, letterSpacing: '0.02em', cursor: 'pointer' }} onClick={() => window.location.hash = ''}>
          Day Before
        </h1>
      </div>

      <h2 style={{ fontSize: '1.2rem', marginBottom: '24px', fontWeight: 500 }}>
        {isLogin ? 'Log In' : 'Create Account'}
      </h2>

      {error && <div style={{ color: '#e74c3c', marginBottom: '16px' }}>{error}</div>}

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <input 
          type="email" 
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ padding: '12px', background: 'transparent', border: '1px solid var(--divider)', color: 'var(--text-primary)', fontSize: '1rem', borderRadius: '4px' }}
        />
        <input 
          type="password" 
          placeholder="Passphrase"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{ padding: '12px', background: 'transparent', border: '1px solid var(--divider)', color: 'var(--text-primary)', fontSize: '1rem', borderRadius: '4px' }}
        />
        
        {!isLogin && (
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Because your entries are end-to-end encrypted with your passphrase, we cannot reset it if you forget it.
          </p>
        )}

        <button 
          type="submit" 
          disabled={loading}
          style={{ marginTop: '8px', padding: '12px', background: 'transparent', border: '1px solid var(--text-primary)', color: 'var(--text-primary)', fontSize: '1rem', borderRadius: '4px', cursor: loading ? 'not-allowed' : 'pointer' }}>
          {loading ? 'Processing...' : (isLogin ? 'Log In' : 'Register')}
        </button>
      </form>

      <div style={{ marginTop: '24px', textAlign: 'center' }}>
        <button 
          type="button"
          onClick={() => { setIsLogin(!isLogin); setError(''); }}
          style={{ background: 'transparent', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', textDecoration: 'underline' }}>
          {isLogin ? "Don't have an account? Register" : "Already have an account? Log In"}
        </button>
      </div>
    </div>
  );
}
